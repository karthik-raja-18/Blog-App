import React, { useState, useEffect } from "react";
import axios from "axios";
import "./ViewProfile.css";

const ViewProfilePage = () => {
  const [user, setUser] = useState({ username: "", password: "" });
  const [isEditingUsername, setIsEditingUsername] = useState(false);
  const [isEditingPassword, setIsEditingPassword] = useState(false);
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  useEffect(() => {
    // Fetch current user details from backend
    axios
      .get("/api/user/profile", { withCredentials: true })
      .then((response) => {
        setUser({ username: response.data.username, password: response.data.password });
      })
      .catch((error) => console.error("Error fetching user details:", error));
  }, []);

  // Handle Username Update
  const handleUsernameUpdate = () => {
    axios
      .put("/api/user/update", { username: user.username })
      .then(() => {
        alert("Username updated successfully");
        setIsEditingUsername(false);
      })
      .catch((error) => console.error("Error updating username:", error));
  };

  // Handle Password Update
  const handlePasswordUpdate = () => {
    if (newPassword !== confirmPassword) {
      alert("New password and confirm password don't match.");
      return;
    }

    axios
      .put("/api/user/update-password", { currentPassword, newPassword })
      .then(() => {
        alert("Password updated successfully");
        setIsEditingPassword(false);
        setCurrentPassword("");
        setNewPassword("");
        setConfirmPassword("");
      })
      .catch((error) => console.error("Error updating password:", error));
  };

  return (
    <div>
      {/* Navigation Bar */}
      <nav className="navbar">
        <h2>My App</h2>
        <ul>
          <li><a href="/">Home</a></li>
          <li><a href="/profile" className="active">Profile</a></li>
          <li><a href="/logout">Logout</a></li>
        </ul>
      </nav>

      <div className="view-profile-container">
        <h1>Profile</h1>

        {/* Username Section */}
        <div className="form-group">
          <label>Username:</label>
          {isEditingUsername ? (
            <>
              <input
                type="text"
                value={user.username}
                onChange={(e) => setUser({ ...user, username: e.target.value })}
                required
              />
              <button onClick={handleUsernameUpdate}>Save</button>
              <button className="cancel" onClick={() => setIsEditingUsername(false)}>Cancel</button>
            </>
          ) : (
            <>
              <p>{user.username}</p>
              <button onClick={() => setIsEditingUsername(true)}>Edit</button>
            </>
          )}
        </div>

        {/* Password Section */}
        <div className="form-group">
          <label>Password:</label>
          {isEditingPassword ? (
            <>
              <label>Current Password:</label>
              <input
                type="password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                required
              />
              <label>New Password:</label>
              <input
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                required
              />
              <label>Confirm New Password:</label>
              <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
              />
              <button onClick={handlePasswordUpdate}>Save</button>
              <button className="cancel" onClick={() => setIsEditingPassword(false)}>Cancel</button>
            </>
          ) : (
            <>
              <p>{user.password}</p> {/* Display masked password */}
              <button onClick={() => setIsEditingPassword(true)}>Change Password</button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default ViewProfilePage;