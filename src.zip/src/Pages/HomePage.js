// src/components/HomePage.js
import React, { useState, useEffect } from 'react';
import { useNavigate, Link, useLocation } from 'react-router-dom';
import './Home.css';
import './Header.css';
const HomePage = () => {
  const location = useLocation();
  const { username } = location.state || {}; // Get username from state
  const navigate = useNavigate();

  const [blogs, setBlogs] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    fetchBlogs();
  }, []);

  const fetchBlogs = async () => {
    try {
      const response = await fetch('http://localhost:4000/api/posts');
      if (!response.ok) {
        throw new Error('Failed to fetch blogs');
      }
      const data = await response.json();
      setBlogs(data);
    } catch (error) {
      console.error('Failed to fetch blogs:', error);
    }
  };

  const handleSearch = async (e) => {
    e.preventDefault();
    
    if (!searchQuery.trim()) {
      fetchBlogs(); // Refetch all blogs if search query is empty
      return;
    }

    try {
      const response = await fetch(`http://localhost:4000/api/search?title=${searchQuery}`);
      if (!response.ok) {
        throw new Error('Search failed');
      }
      
      const data = await response.json();
      setBlogs(data);
    } catch (error) {
      console.error('Search failed:', error);
    }
  };

  return (
    <div>
      {/* Navbar Section */}
      <nav className="navbar">
        <h2 className="logo">BloGNow</h2>
        <div className="navLinks">
          <Link to="/create-blog" className="link">Create Blog</Link>
          <Link to="/blogs" className="link">Manage Blog</Link>
          <Link to="/profile" className="link">My Profile</Link>
          <Link to="/subscription" className="link">Subscription</Link>
          <form onSubmit={handleSearch} className="searchForm">
            <input
              type="text"
              placeholder="Search Blog Title..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="searchInput"
            />
            <button type="submit" className="searchButton">Search</button>
          </form>
          <span className="username">Welcome, {username || 'Guest'}</span>
        </div>
      </nav>

      {/* Welcome Section */}
      <div className="container">
        <h1 className="title">
          Welcome {username ? username : 'to My Blog'}
        </h1>
        <p className="subtitle">
          Welcome to the world of ideas and inspiration. We are glad to have you here!
        </p>
      </div>

      {/* Recommended Blogs Section */}
      <div className="blogContainer">
        <h2>Recommended Blogs</h2>
        {blogs.length === 0 ? (
          <p>No blogs found</p>
        ) : (
          blogs.map((blog) => (
            <div key={blog._id} className="blogCard" onClick={() => navigate(`/blog/${blog._id}`)}>
              <h3>{blog.title}</h3>
              <p>{blog.description}</p>
              <p><strong>Author:</strong> {blog.author}</p>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default HomePage;
