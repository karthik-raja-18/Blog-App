import React from 'react';
import { Link } from 'react-router-dom';
import { FaSearch } from 'react-icons/fa'; // Import search icon from React Icons
import './Header.css';

export default function Header() {
  return (
    <header className="header">
      <nav>
        <Link to="/home">Home</Link>
        <Link to="/blogs">My Blog</Link>
        <Link to="/create-blog
        ">Create Post</Link>
        <Link to="/contact">Contact</Link>
        <Link to="/Subscription">Subscribe</Link>
      </nav>
      <div className="search-container">
        <FaSearch className="search-icon" />
        <input type="text" className="search-bar" placeholder="Search..." />
      </div>
    </header>
  );
}