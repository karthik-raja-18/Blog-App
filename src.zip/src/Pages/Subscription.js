import React from 'react';
import './Subscription.css';

const SubscriptionPage = () => {
  return (
    <div className="subscription-container">
      <h1>Subscription Plans</h1>
      <p>Select a plan that suits your needs.</p>
    </div>
  );
};

export default SubscriptionPage;
