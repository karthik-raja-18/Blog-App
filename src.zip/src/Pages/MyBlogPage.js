import React, { useEffect, useState } from 'react';
import "./ManageBlog.css"; // ✅ Correct import path
import "./Header.css"; // ✅ Correct import path

const MyBlogPage = () => {
  const [blogs, setBlogs] = useState([]);

  useEffect(() => {
    const fetchBlogs = async () => {
      try {
        const response = await fetch('http://localhost:4000/blogs');
        const data = await response.json();
        setBlogs(data.blogs);
      } catch (error) {
        console.error('Error fetching blogs:', error);
      }
    };
    fetchBlogs();
  }, []); // Fetch blogs when the component mounts

  return (
    <div className="my-blogs">
      {blogs.length > 0 ? (
        <ul>
          {blogs.map((blog) => (
            <li key={blog._id}>
              <h3>{blog.title}</h3>
              <p>{blog.content}</p>
              <p><em>{blog.category}</em></p>
              <p>Author: {blog.author}</p>
              <p>Posted on: {new Date(blog.createdAt).toLocaleDateString()}</p>
            </li>
          ))}
        </ul>
      ) : (
        <p>No blogs found</p>
      )}
    </div>
  );
};

export default MyBlogPage;
