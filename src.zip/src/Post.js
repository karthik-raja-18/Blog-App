import React from 'react'

export const Post = () => {
  return (
    <div>
      <h1>This is My Posts</h1>
    </div>
  )
}
export default Post