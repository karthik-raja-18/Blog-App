import React from 'react'

export const header = () => {
  return (
    <div>This is My header</div>
  )
}
export default header